	component soc_system is
		port (
			clk_clk                       : in    std_logic                     := 'X';             -- clk
			hps_0_h2f_reset_reset_n       : out   std_logic;                                        -- reset_n
			memory_mem_a                  : out   std_logic_vector(14 downto 0);                    -- mem_a
			memory_mem_ba                 : out   std_logic_vector(2 downto 0);                     -- mem_ba
			memory_mem_ck                 : out   std_logic;                                        -- mem_ck
			memory_mem_ck_n               : out   std_logic;                                        -- mem_ck_n
			memory_mem_cke                : out   std_logic;                                        -- mem_cke
			memory_mem_cs_n               : out   std_logic;                                        -- mem_cs_n
			memory_mem_ras_n              : out   std_logic;                                        -- mem_ras_n
			memory_mem_cas_n              : out   std_logic;                                        -- mem_cas_n
			memory_mem_we_n               : out   std_logic;                                        -- mem_we_n
			memory_mem_reset_n            : out   std_logic;                                        -- mem_reset_n
			memory_mem_dq                 : inout std_logic_vector(31 downto 0) := (others => 'X'); -- mem_dq
			memory_mem_dqs                : inout std_logic_vector(3 downto 0)  := (others => 'X'); -- mem_dqs
			memory_mem_dqs_n              : inout std_logic_vector(3 downto 0)  := (others => 'X'); -- mem_dqs_n
			memory_mem_odt                : out   std_logic;                                        -- mem_odt
			memory_mem_dm                 : out   std_logic_vector(3 downto 0);                     -- mem_dm
			memory_oct_rzqin              : in    std_logic                     := 'X';             -- oct_rzqin
			reset_reset_n                 : in    std_logic                     := 'X';             -- reset_n
			reset_bridge_0_in_reset_reset : in    std_logic                     := 'X';             -- reset
			video_clk_clk                 : in    std_logic                     := 'X';             -- clk
			pixel_out_data                : out   std_logic_vector(7 downto 0);                     -- data
			pixel_out_valid               : out   std_logic;                                        -- valid
			pixel_out_ready               : in    std_logic                     := 'X';             -- ready
			pixel_out_startofpacket       : out   std_logic;                                        -- startofpacket
			pixel_out_endofpacket         : out   std_logic;                                        -- endofpacket
			video_out_reset_reset         : in    std_logic                     := 'X'              -- reset
		);
	end component soc_system;

	u0 : component soc_system
		port map (
			clk_clk                       => CONNECTED_TO_clk_clk,                       --                     clk.clk
			hps_0_h2f_reset_reset_n       => CONNECTED_TO_hps_0_h2f_reset_reset_n,       --         hps_0_h2f_reset.reset_n
			memory_mem_a                  => CONNECTED_TO_memory_mem_a,                  --                  memory.mem_a
			memory_mem_ba                 => CONNECTED_TO_memory_mem_ba,                 --                        .mem_ba
			memory_mem_ck                 => CONNECTED_TO_memory_mem_ck,                 --                        .mem_ck
			memory_mem_ck_n               => CONNECTED_TO_memory_mem_ck_n,               --                        .mem_ck_n
			memory_mem_cke                => CONNECTED_TO_memory_mem_cke,                --                        .mem_cke
			memory_mem_cs_n               => CONNECTED_TO_memory_mem_cs_n,               --                        .mem_cs_n
			memory_mem_ras_n              => CONNECTED_TO_memory_mem_ras_n,              --                        .mem_ras_n
			memory_mem_cas_n              => CONNECTED_TO_memory_mem_cas_n,              --                        .mem_cas_n
			memory_mem_we_n               => CONNECTED_TO_memory_mem_we_n,               --                        .mem_we_n
			memory_mem_reset_n            => CONNECTED_TO_memory_mem_reset_n,            --                        .mem_reset_n
			memory_mem_dq                 => CONNECTED_TO_memory_mem_dq,                 --                        .mem_dq
			memory_mem_dqs                => CONNECTED_TO_memory_mem_dqs,                --                        .mem_dqs
			memory_mem_dqs_n              => CONNECTED_TO_memory_mem_dqs_n,              --                        .mem_dqs_n
			memory_mem_odt                => CONNECTED_TO_memory_mem_odt,                --                        .mem_odt
			memory_mem_dm                 => CONNECTED_TO_memory_mem_dm,                 --                        .mem_dm
			memory_oct_rzqin              => CONNECTED_TO_memory_oct_rzqin,              --                        .oct_rzqin
			reset_reset_n                 => CONNECTED_TO_reset_reset_n,                 --                   reset.reset_n
			reset_bridge_0_in_reset_reset => CONNECTED_TO_reset_bridge_0_in_reset_reset, -- reset_bridge_0_in_reset.reset
			video_clk_clk                 => CONNECTED_TO_video_clk_clk,                 --               video_clk.clk
			pixel_out_data                => CONNECTED_TO_pixel_out_data,                --               pixel_out.data
			pixel_out_valid               => CONNECTED_TO_pixel_out_valid,               --                        .valid
			pixel_out_ready               => CONNECTED_TO_pixel_out_ready,               --                        .ready
			pixel_out_startofpacket       => CONNECTED_TO_pixel_out_startofpacket,       --                        .startofpacket
			pixel_out_endofpacket         => CONNECTED_TO_pixel_out_endofpacket,         --                        .endofpacket
			video_out_reset_reset         => CONNECTED_TO_video_out_reset_reset          --         video_out_reset.reset
		);

