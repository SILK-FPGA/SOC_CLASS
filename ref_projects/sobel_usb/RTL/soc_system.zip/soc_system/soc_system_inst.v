	soc_system u0 (
		.clk_clk                       (<connected-to-clk_clk>),                       //                     clk.clk
		.hps_0_h2f_reset_reset_n       (<connected-to-hps_0_h2f_reset_reset_n>),       //         hps_0_h2f_reset.reset_n
		.memory_mem_a                  (<connected-to-memory_mem_a>),                  //                  memory.mem_a
		.memory_mem_ba                 (<connected-to-memory_mem_ba>),                 //                        .mem_ba
		.memory_mem_ck                 (<connected-to-memory_mem_ck>),                 //                        .mem_ck
		.memory_mem_ck_n               (<connected-to-memory_mem_ck_n>),               //                        .mem_ck_n
		.memory_mem_cke                (<connected-to-memory_mem_cke>),                //                        .mem_cke
		.memory_mem_cs_n               (<connected-to-memory_mem_cs_n>),               //                        .mem_cs_n
		.memory_mem_ras_n              (<connected-to-memory_mem_ras_n>),              //                        .mem_ras_n
		.memory_mem_cas_n              (<connected-to-memory_mem_cas_n>),              //                        .mem_cas_n
		.memory_mem_we_n               (<connected-to-memory_mem_we_n>),               //                        .mem_we_n
		.memory_mem_reset_n            (<connected-to-memory_mem_reset_n>),            //                        .mem_reset_n
		.memory_mem_dq                 (<connected-to-memory_mem_dq>),                 //                        .mem_dq
		.memory_mem_dqs                (<connected-to-memory_mem_dqs>),                //                        .mem_dqs
		.memory_mem_dqs_n              (<connected-to-memory_mem_dqs_n>),              //                        .mem_dqs_n
		.memory_mem_odt                (<connected-to-memory_mem_odt>),                //                        .mem_odt
		.memory_mem_dm                 (<connected-to-memory_mem_dm>),                 //                        .mem_dm
		.memory_oct_rzqin              (<connected-to-memory_oct_rzqin>),              //                        .oct_rzqin
		.reset_reset_n                 (<connected-to-reset_reset_n>),                 //                   reset.reset_n
		.reset_bridge_0_in_reset_reset (<connected-to-reset_bridge_0_in_reset_reset>), // reset_bridge_0_in_reset.reset
		.video_clk_clk                 (<connected-to-video_clk_clk>),                 //               video_clk.clk
		.pixel_out_data                (<connected-to-pixel_out_data>),                //               pixel_out.data
		.pixel_out_valid               (<connected-to-pixel_out_valid>),               //                        .valid
		.pixel_out_ready               (<connected-to-pixel_out_ready>),               //                        .ready
		.pixel_out_startofpacket       (<connected-to-pixel_out_startofpacket>),       //                        .startofpacket
		.pixel_out_endofpacket         (<connected-to-pixel_out_endofpacket>),         //                        .endofpacket
		.video_out_reset_reset         (<connected-to-video_out_reset_reset>)          //         video_out_reset.reset
	);

